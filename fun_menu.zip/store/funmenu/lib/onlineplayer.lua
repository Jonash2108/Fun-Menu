pedmodelattack = {}
generate_features = function(pid)
	menu.divider(menu.player_root(pid),'Fun menu')
	pedmodelattack[pid] = 0
	-------------------------------------vehicle menu--------------------------------------------
	local vehonlinemenu = menu.list(menu.player_root(pid), VEH_ONLINE_MENU, {}, "")
	local lunchvehmenu = menu.list(vehonlinemenu, VEH_LUNCH_MENU, {}, "")
	local haltvehmenu = menu.list(vehonlinemenu, HALT_VEH_SUBMENU, {}, "")

	menu.action(lunchvehmenu, LUNCH_UP, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, 0, 0, 100000, false, true, true, true)
	end)
	menu.action(lunchvehmenu, LUNCH_DOWN, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, 0, 0, -100000, false, true, true, true)
	end)
	menu.action(lunchvehmenu, LUNCH_RIGHT, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, 100000, 0, 0, false, true, true, true)
	end)
	menu.action(lunchvehmenu, LUNCH_LEFT, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, -100000, 0, 0, false, true, true, true)
	end)
	menu.action(lunchvehmenu, LUNCH_FOWARD, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, 0, 100000, 0, false, true, true, true)
	end)
	menu.action(lunchvehmenu, LUNCH_BACKWARD, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(getveh(pid), 1, 0, -100000, 0, false, true, true, true)
	end)

	menu.action(vehonlinemenu, EXPL_PLY_VEH, {}, "", function()
		requestControlLoop(getveh(pid))
		NETWORK.NETWORK_EXPLODE_VEHICLE(getveh(pid), true, true, false)
	end)

	menu.action(vehonlinemenu, ROT_180, {}, "", function()
		tick = 0
		head = ENTITY.GET_ENTITY_HEADING(getveh(pid))
		pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
		headc = head+180
		if headc>360 then 
			headf = headc-360
		else
			headf = headc
		end
		while (tick < 25)do
			requestControlLoop(getveh(pid))
			head = ENTITY.GET_ENTITY_HEADING(getveh(pid))
			requestControlLoop(getveh(pid))
			ENTITY.SET_ENTITY_HEADING(getveh(pid), headf)
			tick = tick +1
			util.yield(10)
		end
	end)
	menu.action(vehonlinemenu, TRP_OCEAN, {}, "", function()
		requestControlLoop(getveh(pid))
		ENTITY.SET_ENTITY_COORDS_NO_OFFSET(getveh(pid), '-7000', '-743', '45')
	end)

	menu.action(haltvehmenu, HALT_VEH, {}, "", function()
		requestControlLoop(getveh(pid))
		VEHICLE.BRING_VEHICLE_TO_HALT(getveh(pid), getmenuvalueplayer(pid, VEH_ONLINE_MENU..">"..HALT_VEH_SUBMENU..">"..HALT_DISTANCE_VEH), getmenuvalueplayer(pid, VEH_ONLINE_MENU..">"..HALT_VEH_SUBMENU..">"..HALT_TIME_VEH))
	end)
	
	menu.slider(haltvehmenu, HALT_DISTANCE_VEH, {"haltdist"}, HALT_DISTANCE_VEH_DESC, 0, 2147483646, 0, 1, function(s)
		
	end)

	menu.slider(haltvehmenu, HALT_TIME_VEH, {"halttime"}, HALT_TIME_VEH_DESC, 1, 2147483646, 1, 1, function(s)
		
	end)
	menu.action(vehonlinemenu, FIX_VEH_ONLINE, {}, "", function()
		requestControlLoop(getveh(pid))
		fixveh(getveh(pid))
	end)

	menu.toggle(vehonlinemenu, NO_LOCK_ON, {""}, "", function(on)
		while (menu.get_value(menu.ref_by_path("Players>"..players.get_name_with_tags(pid)..">"..VEH_ONLINE_MENU..">"..NO_LOCK_ON)) == 1) do
			util.yield(10000)
			VEHICLE._SET_VEHICLE_CAN_BE_LOCKED_ON(getveh(pid), false)
			requestControlLoop(getveh(pid))
			util.yield()
		end
		requestControlLoop(getveh(pid))
		VEHICLE._SET_VEHICLE_CAN_BE_LOCKED_ON(getveh(pid), true)
	end)
	menu.action(vehonlinemenu, CHILD_LOCK, {}, "", function()
		VEHICLE.SET_VEHICLE_DOORS_LOCKED(getveh(pid), 4)
	end)
	-------------------------------------Vehicle menu end--------------------------------------------
	-------------------------------------Trolling menu--------------------------------------------
	local trollonlinemenu = menu.list(menu.player_root(pid), TROLL_MENU, {}, "")
	local pedattackmenu = menu.list(trollonlinemenu, PED_ATTACK_MENU, {}, "")
	local settingpedattackmenu = menu.list(pedattackmenu, SETTING_PED_ATTACK_MENU, {}, "")

	menu.toggle(settingpedattackmenu, INVIC_PED_ATTACKER, {""}, "", function()
		
	end)
	menu.toggle(settingpedattackmenu, INV_PED_ATTACKER, {""}, "", function()
		
	end)
	menu.toggle(settingpedattackmenu, SPAWN_ON_PLAYER, {""}, SPAWN_ON_PLAYER_DESC, function()
		
	end)
	menu.text_input(pedattackmenu, PED_ATTACK_MODEL, {"attackmodel"}, "", function(s)
		pedmodelattack[pid] = s
	end)
	
	menu.slider(pedattackmenu, NUMBER_PED_ATTACK, {""}, "", 0, 20, 1, 1, function()
	
	end)
	menu.action(pedattackmenu, SPAWN_ATTACKER, {}, "", function()
		pedmodelforattack = pedmodelattack[pid]
		if (getmenuvalueplayer(pid, TROLL_MENU..">"..PED_ATTACK_MENU..">"..SETTING_PED_ATTACK_MENU..">"..SPAWN_ON_PLAYER) == 0) then
			doesspawnonplayer = false
		else
			doesspawnonplayer = true
		end
		if (getmenuvalueplayer(pid, TROLL_MENU..">"..PED_ATTACK_MENU..">"..SETTING_PED_ATTACK_MENU..">"..INVIC_PED_ATTACKER) == 0) then
			isinvicible = false
		else
			isinvicible = true
		end
		if (getmenuvalueplayer(pid, TROLL_MENU..">"..PED_ATTACK_MENU..">"..SETTING_PED_ATTACK_MENU..">"..INV_PED_ATTACKER) == 0) then
			isinvisible = false
		else
			isinvisible = true
		end
		whatmodel = getmenuvalueplayer(pid, TROLL_MENU..">"..PED_ATTACK_MENU..">"..PED_ATTACK_MODEL)
		numbertospawn = getmenuvalueplayer(pid, TROLL_MENU..">"..PED_ATTACK_MENU..">"..NUMBER_PED_ATTACK)
		spawnpedattack(pid, pedmodelforattack, numbertospawn, isinvicible, isinvisible, doesspawnonplayer)
	end)

	menu.toggle(trollonlinemenu, PLANE_ATTACK, {"planeattack"}, "", function(on)
	posplane = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
		if (getmenuvalueplayer(pid, TROLL_MENU..">"..PLANE_ATTACK) == 1) then
			planespawnz = 100
			headplane = 0
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
			spawnplaneforattack(posplane, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid), planespawnz, headplane)
			planespawnz = planespawnz+10
			headplane = headplane+36
		end
		while (getmenuvalueplayer(pid, TROLL_MENU..">"..PLANE_ATTACK) == 1) do
		
			util.yield()
		end
		if (getmenuvalueplayer(pid, "Spectate>Ninja Method") == 0) then
			menu.trigger_commands("spectate"..PLAYER.GET_PLAYER_NAME(pid).." on")
		end
		util.yield(1000)
		delattackplane("Lazer")
		if (getmenuvalueplayer(pid, "Spectate>Ninja Method") == 1) then
			menu.trigger_commands("spectate"..PLAYER.GET_PLAYER_NAME(pid).." off")
		end
	end)

	-------------------------------------Trolling menu end--------------------------------------------

	menu.toggle(menu.player_root(pid), GHOST_PLAYER, {}, "", function(toggle)
		 NETWORK._SET_RELATIONSHIP_TO_PLAYER(pid, toggle)
		 
	end)
	menu.action(menu.player_root(pid), COPY_INFO, {}, "", function()
		util.copy_to_clipboard("Name : "..players.get_name(pid)..string.char(10).."RID : "..players.get_rockstar_id(pid))
	end)
	--[[menu.action(menu.player_root(pid), "test", {}, "", function()
		menu.focus(menu.ref_by_path("Players>"..players.get_name_with_tags(0)..">Information>Connection>Connect Address>IP Address"))
		util.yield(100)
		menu.trigger_command(menu.ref_by_path("Players>"..players.get_name_with_tags(0)..">Information>Connection>Connect Address>IP Address"),"")
		local ip = util.get_clipboard_text()
		menu.trigger_command(menu.ref_by_path("Players>"..players.get_name_with_tags(0)..">Information>Connection>Connect Address>City"),"")
		city = util.get_clipboard_text()
		menu.trigger_command(menu.ref_by_path("Players>"..players.get_name_with_tags(0)..">Information>Connection>Connect Address>Region"),"")
		region = util.get_clipboard_text()
		menu.trigger_command(menu.ref_by_path("Players>"..players.get_name_with_tags(0)..">Information>Connection>Connect Address>Country"),"")
		country = util.get_clipboard_text()
		menu.focus(menu.ref_by_path("Players>"..players.get_name_with_tags(pid)..">test"))
		menu.trigger_commands("smstext"..PLAYER.GET_PLAYER_NAME(pid).." IP : "..ip.."Location : "..country..", "..region..", "..city)
		menu.trigger_commands("smssend"..PLAYER.GET_PLAYER_NAME(pid))
	end)
	menu.action(menu.player_root(pid), "test", {}, "", function()
		util.toast(pedmodelattack[pid])
	end)]]
end

for _, pId in ipairs(players.list()) do
	generate_features(pId)
end
players.on_join(generate_features)
